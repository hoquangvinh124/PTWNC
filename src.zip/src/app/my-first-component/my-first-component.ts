import { Component } from '@angular/core';

@Component({
  selector: 'app-my-first-component',
  imports: [],
  templateUrl: './my-first-component.html',
  styleUrl: './my-first-component.css',
})
export class MyFirstComponent {

}
