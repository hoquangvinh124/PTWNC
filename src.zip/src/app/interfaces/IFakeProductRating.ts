export interface IFakeProductRating {
  rate: number;
  count: number;
}
